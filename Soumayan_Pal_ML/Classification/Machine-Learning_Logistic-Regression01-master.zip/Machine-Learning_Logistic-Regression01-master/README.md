# Machine-Learning_Logistic-Regression01
To classify Passed and Failed data in Driving Tests and find the probability using logistic regression( using Gradient Descent algorithm
