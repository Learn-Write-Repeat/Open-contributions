# Multi_Linear-Regression
To predict the sales revenue for advertisement of a company through TV, radio and newspaper.
