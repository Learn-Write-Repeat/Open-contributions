# Machine-Learning_Linear-Rgression
Performing Linear Regression on random numbers using Gradient Descent algorithm.
